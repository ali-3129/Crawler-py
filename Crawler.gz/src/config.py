BASE_LINK = 'https://{}.craigslist.org/search/hhh?availabilityMode=0&lang=en&cc=gb&s='

STORAGE_TYPE = 'mongo'  # choices: ['mongo', 'file']
